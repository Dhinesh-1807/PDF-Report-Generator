import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

import java.io.*;
import java.util.*;

public class PDFReportGenerator {
    public void generateReport(List<Employee> employees, String outputPath) throws IOException {
        PDDocument doc = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        doc.addPage(page);

        PDPageContentStream content = new PDPageContentStream(doc, page);
        PDFont font = PDType1Font.HELVETICA_BOLD;

        content.beginText();
        content.setFont(font, 18);
        content.setLeading(22.5f);
        content.newLineAtOffset(50, 750);
        content.showText("Employee Report");
        content.newLine();
        content.newLine();
        content.setFont(PDType1Font.HELVETICA, 12);

        for (Employee emp : employees) {
            content.showText("ID: " + emp.getId() + " | " + emp.getName() + " | " + emp.getDepartment() + " | ₹" + emp.getSalary());
            content.newLine();
        }

        content.endText();
        content.close();

        doc.save(outputPath);
        doc.close();
    }
}