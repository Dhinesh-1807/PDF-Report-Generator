import java.io.*;
import java.util.*;

public class CSVReader {
    public List<Employee> readCSV(String filePath) throws Exception {
        List<Employee> list = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        reader.readLine(); // skip header

        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            list.add(new Employee(
                Integer.parseInt(parts[0]),
                parts[1],
                parts[2],
                parts[3],
                Double.parseDouble(parts[4])
            ));
        }
        reader.close();
        return list;
    }
}