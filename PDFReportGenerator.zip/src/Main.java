import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        List<Employee> employees = new CSVReader().readCSV("data/employees.csv");
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String filename = "reports/employee_report_" + timestamp + ".pdf";

        new PDFReportGenerator().generateReport(employees, filename);
        System.out.println("Report generated: " + filename);
    }
}